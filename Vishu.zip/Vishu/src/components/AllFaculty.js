import React from 'react'

export default function AllFaculty() {
  return (
    <div>AllFaculty</div>
  )
}
