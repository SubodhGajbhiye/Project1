import React from 'react'

export default function FacultyLogin() {
  return (
    <div>FacultyLogin</div>
  )
}
